export const hostApi = 'http://20.115.58.35:8080/api/v1/auth/';
export const hostGets = 'http://20.115.58.35:8080/api/v1/';