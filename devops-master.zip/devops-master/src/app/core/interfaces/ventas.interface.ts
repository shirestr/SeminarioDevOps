export enum Color{
    rojo, color, azul, verde, negro
}

export interface Heroe{
    nombre: string;
    vuela: boolean;
    color: Color;
}